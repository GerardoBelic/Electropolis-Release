using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Avatar : MonoBehaviour
{

    /*#region TEMPORAL

    public Transform _1;
    public Transform _2;
    public Transform _3;
    public Transform _4;
    public Transform _5;
    public Transform _6;
    public Building b;

    void Update()
    {
        if (_6 != null)
        {
            Route r = new Route(_1, _2, _3, _4, _5, _6, b);
            start_route(r);
            _1 = _2 = _3 = _4 = _5 = _6 = null;
            b = null;

        }
    }

    #endregion*/
    
    public GameObject human_gameobject = null;
    public NavMeshAgent human_agent = null;

    public GameObject car_gameobject = null;
    public NavMeshAgent car_agent = null;

    public Route avatar_route = null;

    public static float wait_time_until_path_computes = 0.5f;
    public static float wait_time_until_target_reached = 2.0f;

    private Coroutine executing_route = null;
    public void start_route(Route route)
    {
        avatar_route = route;

        executing_route = StartCoroutine(consume_route());
    }

    private IEnumerator wait_until_path_computes(NavMeshAgent agent)
    {
        while (agent.pathPending)
        {
            yield return new WaitForSeconds(wait_time_until_path_computes);
        }
    }

    private IEnumerator wait_until_target_reached(NavMeshAgent agent)
    {
        while (agent.remainingDistance > 0.05f)
        {
            //print("Distance: " + agent.remainingDistance);
            //print("isOnNavMesh: " + agent.isOnNavMesh);
            //print("isPathStale: " + agent.isPathStale);
            //print("pathStatus: " + agent.pathStatus);

            /// If the path is invalidated due to a road/building deletion, skip the path completition
            if (agent.pathStatus == NavMeshPathStatus.PathInvalid)
            {
                yield break;
            }
            yield return new WaitForSeconds(wait_time_until_target_reached);
        }
    }
    
    private IEnumerator consume_route()
    {
        /// We start spawning the human in the starting point
        human_gameobject.transform.position = avatar_route.get_starting_point().position;
        human_gameobject.SetActive(true);

        while (true)
        {
            (Route_Phase route_phase, Transform target) = avatar_route.consume_route_phase();

            /// If we have consumed all the route phases stop the coroutine
            if (route_phase == Route_Phase.Finished)
            {
                human_gameobject.SetActive(false);

                /// Notify that we have reached our destination

                yield break;
            }

            /// If we haven't finished the route phases but a target is null, just transport the citizen to the building
            if (target == null)
            {
                human_gameobject.SetActive(false);

                /// Notify that we have reached our destination

                yield break;
            }

            if (route_phase == Route_Phase.Teleport_To_Walk)
            {
                car_gameobject.SetActive(false);

                human_gameobject.transform.position = target.position;
                human_gameobject.SetActive(true);
                
                continue;
            }
            else if (route_phase == Route_Phase.Teleport_To_Drive)
            {
                human_gameobject.SetActive(false);

                car_gameobject.transform.position = target.position;
                car_gameobject.SetActive(true);

                continue;
            }
            else if (route_phase == Route_Phase.Walk)
            {
                human_agent.SetDestination(target.position);

                yield return StartCoroutine(wait_until_path_computes(human_agent));

                yield return StartCoroutine(wait_until_target_reached(human_agent));

                continue;
            }
            else if (route_phase == Route_Phase.Drive)
            {
                car_agent.SetDestination(target.position);

                yield return StartCoroutine(wait_until_path_computes(car_agent));

                yield return StartCoroutine(wait_until_target_reached(car_agent));

                continue;
            }
        }
    }

}
